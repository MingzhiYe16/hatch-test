# SPDX-FileCopyrightText: 2023-present MingzhiYe16 <1626384862@qq.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
